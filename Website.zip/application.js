const container = document.getElementById("applicationsContainer");
const count = document.getElementById("applicationCount");
const filter = document.getElementById("statusFilter");
const emptyMsg = document.getElementById("emptyMessage");

let applications = JSON.parse(localStorage.getItem("lockInApplications")) || [];

function renderApplications() {
    const status = filter.value;
    const filtered = status === "All" ? applications : applications.filter(a => a.status === status);
    
    container.innerHTML = "";
    count.innerText = `${filtered.length} applications`;

    if(filtered.length === 0){
        emptyMsg.style.display = "block";
        return;
    }
    emptyMsg.style.display = "none";

    filtered.forEach(app => {
        const card = document.createElement("div");
        card.className = "application-card";
        card.innerHTML = `
            <div class="card-header">
                <h3>${app.fullname}</h3>
                <span class="application-status" style="background:${app.status==='Approved'?'green':app.status==='Rejected'?'red':'#ff4d00'}">${app.status}</span>
            </div>
            <div class="card-info">
                <p><strong>WhatsApp:</strong> ${app.whatsapp}</p>
                <p><strong>Email:</strong> ${app.email || 'N/A'}</p>
                <p><strong>Occupation:</strong> ${app.occupation}</p>
                <p><strong>Country:</strong> ${app.country}</p>
                <p><strong>Submitted:</strong> ${app.submittedAt}</p>
            </div>
            <div class="goal-preview">
                <strong>12 Month Goal</strong>
                <p>${app.goal_12months}</p>
            </div>
            <button class="view-details" onclick="updateStatus(${app.id}, 'Approved')">Approve</button>
            <button class="view-details" style="background:red; margin-top:8px;" onclick="updateStatus(${app.id}, 'Rejected')">Reject</button>
        `;
        container.appendChild(card);
    });
}

function updateStatus(id, newStatus){
    applications = applications.map(app => app.id === id ? {...app, status: newStatus} : app);
    localStorage.setItem("lockInApplications", JSON.stringify(applications));
    renderApplications();
    alert(`Application ${newStatus}!`);
}

filter.addEventListener("change", renderApplications);
renderApplications(); // run on load